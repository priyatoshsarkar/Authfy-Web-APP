import logo from './logo.png';
import header from './header.png';
import logo_home from './logo_home.png'; 
//import logo_home from './logo_home.png';
export const assets = {
    logo,
    header,
    logo_home,
};
